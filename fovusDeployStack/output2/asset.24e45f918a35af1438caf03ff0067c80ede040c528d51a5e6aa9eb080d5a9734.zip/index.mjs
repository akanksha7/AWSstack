import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { EC2Client, RunInstancesCommand, TerminateInstancesCommand, DescribeInstancesCommand,DescribeInstanceStatusCommand, AssociateIamInstanceProfileCommand, RebootInstancesCommand } from "@aws-sdk/client-ec2";
import { SSMClient, SendCommandCommand } from "@aws-sdk/client-ssm";
import { IAMClient, GetInstanceProfileCommand, CreateInstanceProfileCommand } from "@aws-sdk/client-iam";


const ec2Client = new EC2Client({ region: "us-east-1" });
const s3Client = new S3Client({ region: "us-east-1" });
const ssmClient = new SSMClient({ region: "us-east-1" });
const iamClient = new IAMClient({ region: "us-east-1" });

export const handler = async (event) => {
  console.log('DynamoDB event:', JSON.stringify(event, null, 2));

  for (const record of event.Records) {
    if (record.eventName === 'INSERT') {
      var instanceId = null;
      try {
        // 1. Create an EC2 instance that can run Python scripts
        const runInstancesCommand = new RunInstancesCommand({
          ImageId: 'ami-051f8a213df8bc089', // Amazon linux image
          InstanceType: 't2.micro',
          KeyName: 'ec2-instance-key-pair',
          SecurityGroups: ['default'],
          MinCount: 1,
          MaxCount: 1
        });
        const ec2Response = await ec2Client.send(runInstancesCommand);
        instanceId = ec2Response.Instances[0].InstanceId;

        // Create a promise on an EC2 service object
        // var instancePromise = new AWS.EC2({ apiVersion: "2016-11-15" })
        //   .runInstances({
        //   ImageId: 'ami-051f8a213df8bc089', // Amazon linux image
        //   InstanceType: 't2.micro',
        //   KeyName: 'ec2-instance-key-pair',
        //   SecurityGroups: ['default'],
        //   MinCount: 1,
        //   MaxCount: 1
        // }).promise();


        //const instanceId = instancePromise.Instances[0].InstanceId;


        //   await createInstanceProfile("customer-mc-ec2-instance-profile");

        //   await assignIamRoleToEc2Instance(instanceId, 'customer-mc-ec2-instance-profile');

        //   await rebootEc2Instance(instanceId);


        //   sleep(2000);
        //instanceId = "i-06d3133be3a42afdd";
        await waitForInstanceInitialization(instanceId);
        //console.log('EC2 instance created:', instanceId);


        // 2. Download the Python script from S3
        const getObjectCommand = new GetObjectCommand({
          Bucket: 'fovus-script-storage',
          Key: 'output_file_processor.py',
        });

        const scriptResponse = await s3Client.send(getObjectCommand);
        // const scriptContent = await scriptResponse.Body?.transformToString('utf-8');
        const blob = await scriptResponse.Body.transformToByteArray();
        //console.log("Downloaded python script", String.fromCharCode.apply(String, blob));

        // Inside the try block after creating the instance
        try {
          //3. Upload the Python script and the DynamoDB event record to the EC2 instance1
          const sendCommandCommand = new SendCommandCommand({
            InstanceIds: [instanceId],
            DocumentName: "AWS-RunShellScript",
            Parameters: {
              commands: [
                'mkdir -p /tmp/scripts',
                `echo '${JSON.stringify(record)}' > /tmp/scripts/dynamo-event-record.json`,
                `echo "${String.fromCharCode.apply(String, blob)}" > /tmp/scripts/output_file_processor.py`
              ]
            },
          });

          await ssmClient.send(sendCommandCommand);
          console.log("Copied script and record to EC2 instnace");
        }
        catch (error) {
          console.log(error);
        }


        //4. Run the Python script in the EC2 instance
        const runShellScriptCommand = new SendCommandCommand({
          InstanceIds: [instanceId],
          DocumentName: 'AWS-RunShellScript',
          Parameters: {
            commands: [
              'sudo yum install pip -y',
              'pip install boto3',
              'python3 /tmp/scripts/output_file_processor.py /tmp/scripts/dynamo-event-record.json'
            ],
          },
        });
        await ssmClient.send(runShellScriptCommand);

        console.log('Python script execution and EC2 instance termination completed.');
      }
      catch (err) {
        console.error('Error during the process:', err);
      }
      finally {
        // 5. Terminate the EC2 instance
        if (instanceId) {
          const terminateInstancesCommand = new TerminateInstancesCommand({
            InstanceIds: [instanceId],
          });
          await ec2Client.send(terminateInstancesCommand);
        }
      }
    }
  }

  return { statusCode: 200, body: 'Python script execution triggered' };
};


// Function to check if the EC2 instance is in a valid state
const isInstanceInValidState = async (instanceId) => {
  try {
    const describeInstancesCommand = new DescribeInstancesCommand({
      InstanceIds: [instanceId],
    });
    const response = await ec2Client.send(describeInstancesCommand);
    const state = response.Reservations[0].Instances[0].State.Name;
    return state === 'running'; // Change this to the desired valid state
  }
  catch (error) {
    console.error("Error checking instance state:", error);
    return false;
  }
};

// Function to wait until the EC2 instance reaches a valid state
const waitForInstanceValidState = async (instanceId) => {
  const pollingInterval = 5000; // Adjust this value as needed (in milliseconds)
  while (true) {
    const isValidState = await isInstanceInValidState(instanceId);
    if (isValidState) {
      console.log("EC2 instance is in a valid state.");
      break;
    }
    console.log("Waiting for EC2 instance to reach a valid state...");
    await new Promise(resolve => setTimeout(resolve, pollingInterval));
  }
};

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function assignIamRoleToEc2Instance(instanceId, instanceProfileName) {
  try {
    // Get the Instance Profile ARN
    const getInstanceProfileCommand = new GetInstanceProfileCommand({
      InstanceProfileName: instanceProfileName,
    });
    const instanceProfile = await iamClient.send(getInstanceProfileCommand);
    const instanceProfileArn = instanceProfile.InstanceProfile?.Arn;

    // Associate the IAM Instance Profile with the EC2 instance
    const associateIamInstanceProfileCommand = new AssociateIamInstanceProfileCommand({
      InstanceId: instanceId,
      IamInstanceProfile: {
        Arn: instanceProfileArn,
      },
    });
    await ec2Client.send(associateIamInstanceProfileCommand);

    console.log("IAM role assigned to the EC2 instance successfully.");
  }
  catch (error) {
    console.error("Error assigning IAM role to EC2 instance:", error);
  }
}

async function createInstanceProfile(profileName) {
  try {
    const createInstanceProfileCommand = new CreateInstanceProfileCommand({
      ARN: 'arn:aws:iam::767397931620:role/fovus-file-upload-role',
      InstanceProfileName: profileName,
    });
    const response = await iamClient.send(createInstanceProfileCommand);
    console.log("Instance profile created:", response.InstanceProfile?.InstanceProfileName);
  }
  catch (error) {
    console.error("Error creating instance profile:", error);
  }
}

async function rebootEc2Instance(instanceId) {
  try {
    const rebootInstancesCommand = new RebootInstancesCommand({
      InstanceIds: [instanceId],
    });

    await ec2Client.send(rebootInstancesCommand);
    console.log(`EC2 instance ${instanceId} has been rebooted.`);
  }
  catch (error) {
    console.error(`Error rebooting EC2 instance ${instanceId}:`, error);
  }
}

async function waitForInstanceInitialization(instanceId) {
  const params = {
    InstanceIds: [instanceId]
  };

  try {
    let instanceInitialized = false;
    while (!instanceInitialized) {
      const instanceStatus = await ec2Client.send(new DescribeInstanceStatusCommand(params));
      if (instanceStatus.InstanceStatuses.length > 0) {
        // Check if instance has all status checks passed
        const checksPassed = instanceStatus.InstanceStatuses[0].SystemStatus.Status === "ok" &&
                             instanceStatus.InstanceStatuses[0].InstanceStatus.Status === "ok";
        if (checksPassed) {
          instanceInitialized = true;
        } else {
          console.log("Instance checks not passed yet, waiting...");
          await new Promise(resolve => setTimeout(resolve, 5000)); // Wait for 5 seconds before checking again
        }
      } else {
        console.log("Instance status not available, waiting...");
        await new Promise(resolve => setTimeout(resolve, 5000)); // Wait for 5 seconds before checking again
      }
    }
    return "Instance is initialized";
  } catch (err) {
    console.error(err);
    return "Error checking instance status";
  }
}